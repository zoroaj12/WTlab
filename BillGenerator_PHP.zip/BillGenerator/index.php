<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Electricity Bill Generator</title>
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }

        .form-container {
            width: 400px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div class="form-container">
        <h1 class="text-center mb-4">Electricity Bill Generator</h1>
        <form action="calculate.php" method="GET">

            <div class="form-group">
                <label for="name">Enter Your Name</label>
                <input type="text" class="form-control" name="name" id="name" placeholder="Your Name" required>
            </div>

            <div class="form-group">
                <label for="units">Enter Number of Units</label>
                <input type="number" class="form-control" name="units" id="units" placeholder="Number of Units"
                    required>
            </div>

            <div class="form-group">
                <label for="address">Enter Your Address</label>
                <input type="text" class="form-control" name="address" id="address" placeholder="Your Address" required>
            </div>

            <button type="submit" class="btn btn-primary btn-block">Calculate</button>
        </form>
    </div>

    <!-- Include Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF"
        crossorigin="anonymous"></script>
</body>

</html>