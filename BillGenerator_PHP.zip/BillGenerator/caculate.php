<?php

 $units =$_GET['units'];
$name=$_GET['name'];
$address=$_GET['address'];
    if ($units <= 50) {
        $billAmount = $units * 3.50;
    } elseif ($units <= 150) {
        $billAmount = 50 * 3.50 + ($units - 50) * 4.00;
    } elseif ($units <= 250) {
        $billAmount = 50 * 3.50 + 100 * 4.00 + ($units - 150) * 5.20;
    } else {
        $billAmount = 50 * 3.50 + 100 * 4.00 + 100 * 5.20 + ($units - 250) * 6.50;
    }

    echo"bill for $name <br />
        Living in $address <br />
        is $billAmount <br />
        "
?>