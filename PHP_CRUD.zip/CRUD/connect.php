<?php
$server = "localhost";
$password = "@j1910";
$username = "root";
$database = "crud";

$conn = new mysqli($server, $username, $password, $database);

if (!$conn) {
    die(mysqli_error($conn));
}
?>