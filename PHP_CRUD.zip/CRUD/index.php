<?php

include 'connect.php';

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];

    $sql = "insert into `crud` (name,email,mobile,password) values('$name','$email','$mobile','$password')";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        echo "data inserted succesfully";
        header('location:display.php');
    } else {
        die(mysqli_error($conn));
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD</title>
</head>
<body>
<form action="" method="post">
        <label for="name">Enter your Name</label>
        <input type="text" name="name" placeholder="Enter your Name">
</br>
        <label for="email">Enter your Email</label>
        <input type="text" name="email" placeholder="Enter your Email">
</br>
        <label for="mobile">Enter your Phonenumber</label>
        <input type="number" name="mobile" placeholder="Enter your PhoneNumber">
</br>
        <label for="password">Enter your Password</label>
        <input type="password" name="password" placeholder="Enter your Password">
</br>
    <button type="submit" name="submit">Submit</button>
</form>
</body>
</html>