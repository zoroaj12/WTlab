<?php

session_start();
$servername="localhost";
$username="root";
$password="@j1910";
$database="login";

$conn= @new mysql(
    $servername,
    $username,
    $password,
    $database
);

if($conn->connect_error){
    die("Connection failed: ". $conn->connect_error);
}

?>
