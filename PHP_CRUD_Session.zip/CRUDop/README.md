1. This is a basic PHP CRUD application.
2. You may need to change the database configuration as per your local settings.
